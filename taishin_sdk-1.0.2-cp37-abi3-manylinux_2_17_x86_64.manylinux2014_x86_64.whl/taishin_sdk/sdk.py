from taishin_sdk._taishin_sdk import CoreSDK, Order
from .adapter import Mode, build_websocket_client, build_rest_client


class MarketData:
    def __init__(self, bearer_token, mode):
        self.websocket_client = build_websocket_client(mode, bearer_token)
        self.rest_client = build_rest_client(bearer_token)


class TaishinSDK(CoreSDK):
    """
    fubon sdk for api trading
    """

    def init_realtime(self, account, mode=Mode.Normal):
        """
        Initial market data and get authorised

        """
        sdk_token = super().get_realtime_token(account)
        self.marketdata = MarketData(sdk_token.realtime_token, mode)
